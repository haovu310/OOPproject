package geniemoviesandgames.model.Account;

public interface AccountPromotion {
    void promoteAccount();
}